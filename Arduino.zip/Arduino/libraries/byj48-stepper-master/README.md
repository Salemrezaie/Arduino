# BYJ48 Stepper library

The built-in stepper library uses a different pin sequence that doesn't work optimally. Use this one instead.

The Simple example shows how you can choose optimized pin groups (6-9 or 10-13) which write directly to the ports (without digitalWrite).
